# Suplemento da revisão de 1 de novembro de 2026

Artigo de Vitor Martins Melo, Athos Lial Passos e Jonatan Mariano da Silva.
282 rodadas principais e 20 testes curtos são preservados. Não agrupe sessões, versões, intervenções ou fases como se fossem uma única população.

## Conferência e reprodução

Execute `python conferir-tabelas.py` (biblioteca padrão) para verificar os 355 pontos das sete figuras, as tabelas SQL e os totais. Execute `python gerar-graficos.py` com matplotlib para regenerar as sete figuras PNG/SVG. Elas usam resultados por rodada preservados, sem Docker ou nova carga.

Extraia este ZIP e Dados-brutos.zip na mesma pasta. Execute `node recalcular-brutos.mjs` com Node.js 18+ para conferir as contagens e recalcular p50/p95/p99 de todas as 302 séries de medição. Pode demorar vários minutos. Não inicia testes de carga. Os manifestos SHA-256 registram integridade dos arquivos.

## Organização e proveniência

new-data.json e novos-resultados-por-rodada.csv contêm os 175 novos registros (159 principais + 16 curtos). article-data.json contém somente o histórico de 15, 20 e 29/10, identificado por lote. diagnostico-por-rodada.csv e resultados-por-rodada.csv preservam as tabelas históricas. document-config.json contém as tabelas e legendas da versão atual. dados-das-figuras.csv identifica a origem de cada ponto.

dados/ contém resultados, resumos de aquecimento e registros coletados. ambiente/ contém metadados, configuração e hashes das fontes. codigo-historico-29out/ preserva a cópia anterior; codigo-referencia/ contém as fontes atuais em 01/11. Essas cópias não são substitutos dos manifestos de cada lote, nem prometem recompilar imagens históricas bit a bit. Os binários Docker não estão incluídos. O gerador usa patch local, preservado em instrumento/.

Até 29/10, Feign utilizava Client.Default; desde 30/10 há bean explícito HC5. A partir da validação de 30/10 há inicialização antecipada dos conversores. A JVM 21.0.13+9 aparece já em 30/10; o lote de 01/11 retorna a 21.0.12.1+1 com imagens base fixadas por digest. Planos de energia e versões diferem entre lotes; consulte a Tabela 2 do artigo.

Os arquivos brutos são de medição; séries brutas de aquecimento não estão incluídas, somente seus resumos. Nenhuma amostra foi excluída nos lotes incorporados. Requisições não iniciadas não possuem latência HTTP. Mediana de p95 não é p95 agrupado. Validações são internas, não certificação externa. Os registros incluem nomes de componentes e endereços internos de uma bancada com dados sintéticos.

A licença do depósito deverá ser escolhida pelos autores. Preparação de arquivos não equivale a publicação, revisão por pares ou emissão de certificado.


Revisao visual: SQL e pedidos com linhas de medianas e pontos das repeticoes. Veja COMO-GERAR-GRAFICOS.md. Valores preservados.


Revisão de legibilidade: Figura 3 em quadro numérico; Figuras 4 e 5 em barras de medianas com mínimo–máximo. Suplemento de pedidos de 30/10 com latência logarítmica. Os 355 valores estão preservados. Veja COMO-GERAR-GRAFICOS.md.
